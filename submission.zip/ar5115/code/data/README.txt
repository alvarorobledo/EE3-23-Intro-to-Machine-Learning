This folder contains two csv files: red.csv and white.csv

Each one contains the wine dataset of its colour

Also, all plots are saved in the root of the source code